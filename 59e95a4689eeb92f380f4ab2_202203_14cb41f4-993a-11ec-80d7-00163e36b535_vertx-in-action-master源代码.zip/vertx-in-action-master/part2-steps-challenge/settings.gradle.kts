rootProject.name = "part2-steps-challenge"

include("user-profile-service")
include("activity-service")
include("ingestion-service")
include("congrats-service")
include("event-stats-service")

include("public-api")

include("user-webapp")
include("dashboard-webapp")
